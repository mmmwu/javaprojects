/*
 * @(#)MotifTreeCellRenderer.java	1.11 01/11/29
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.java.swing.plaf.motif;

import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.util.*;

/**
 * Motif rendered to display a tree cell.
 * <p>
 * <strong>Warning:</strong>
 * Serialized objects of this class will not be compatible with
 * future Swing releases.  The current serialization support is appropriate
 * for short term storage or RMI between applications running the same
 * version of Swing.  A future release of Swing will provide support for
 * long term persistence.
 *
 * @version 1.11 11/29/01
 * @author Jeff Dinkins
 */
public class MotifTreeCellRenderer extends DefaultTreeCellRenderer
{
    static final int LEAF_SIZE = 13;
    static final Icon LEAF_ICON = new IconUIResource(new TreeLeafIcon());

    public MotifTreeCellRenderer() {
	super();
    }

    public static Icon loadLeafIcon() {
	return LEAF_ICON;
    }

    /**
     * Icon for a node with no children.
     * <p>
     * <strong>Warning:</strong>
     * Serialized objects of this class will not be compatible with
     * future Swing releases.  The current serialization support is appropriate
     * for short term storage or RMI between applications running the same
     * version of Swing.  A future release of Swing will provide support for
     * long term persistence.
     */
    public static class TreeLeafIcon implements Icon, Serializable {

	Color bg;
	Color shadow;
	Color highlight;

	public TreeLeafIcon() {
	    bg = UIManager.getColor("Tree.iconBackground");
	    shadow = UIManager.getColor("Tree.iconShadow");
	    highlight = UIManager.getColor("Tree.iconHighlight");
	}

	public void paintIcon(Component c, Graphics g, int x, int y) {
	    g.setColor(bg);
	    g.fillRect(4, 7, 5, 5);

	    g.drawLine(6, 6, 6, 6);
	    g.drawLine(3, 9, 3, 9);
	    g.drawLine(6, 12, 6, 12);
	    g.drawLine(9, 9, 9, 9);

	    g.setColor(highlight);
	    g.drawLine(2, 9, 5, 6);
	    g.drawLine(3, 10, 5, 12);

	    g.setColor(shadow);
	    g.drawLine(6, 13, 10, 9);
	    g.drawLine(9, 8, 7, 6);
	    
	}
	
	public int getIconWidth() {
	    return LEAF_SIZE;
	}
	
	public int getIconHeight() {
	    return LEAF_SIZE;
	}
	
    }
}
